#include <stdio.h>

void SelectionSort(int v[], int n)
{
    for(int i=0;i<n-1;i++)
    {
        int iMin=i;
        for(int j=i+1;j<n;j++)
        {
            if(v[j]<v[iMin])
                iMin=j;
        }
        int aux=v[i];
        v[i]=v[iMin];
        v[iMin]=aux;

    }
}
void Binarysearch(int array[],int n)
{
    int first, last, middle, search;
     printf("Enter value to find\n");
   scanf("%d", &search);

   first = 0;
   last = n - 1;
   middle = (first+last)/2;

   while (first <= last) {
      if (array[middle] < search)
         first = middle + 1;
      else if (array[middle] == search) {
         printf("%d found at location %d.\n", search, middle+1);
         break;
      }
      else
         last = middle - 1;

      middle = (first + last)/2;
   }
   if (first > last)
      printf("Not found! %d isn't present in the list.\n", search);

   return 0;
}
int main()
{
    FILE *f;
    f=fopen("C:\\Users\\Kaushik\\Documents\\sortfile.txt", "r");
    if(f==NULL)
    {
        printf("Erro\n");
        return 0;
    }
    int numbers[100], num, i=0;
    while(fscanf(f, "%d", &num)>0)
    {
        numbers[i]=num;
        i++;
    }
    fclose(f);
    printf("%d numbers were read\n", i);
    SelectionSort(numbers, 9);
    for(int i=0;i<9;i++)
    {
        printf("%d --> %d\n", i, numbers[i]);
    }

    Binarysearch(numbers,9);

}
